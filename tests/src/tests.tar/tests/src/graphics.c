/*
** EPITECH PROJECT, 2019
** PSU_zappy_2018
** File description:
** graphics
*/

#include <criterion/criterion.h>
#include "graph_commands.h"

Test(graphics, tna)
{

}
